Thank you for installing Ducky's Arial Text style.

To install for Premiere Pro, drop the file "Duckys Text Arial.prtextstyle" in the following directory:

...\Documents\Adobe\Common\Assets\Text Styles

And locate the text style in the "Properties" window of Premiere Pro.

To use in your project, drag and drop this text style from the "Properties" window into your Project Files.